// Task 9.4

fun main() {
    try {
        print("Enter numerator: ")
        val numerator = readln().toInt()
        print("Enter denominator: ")
        val denominator = readln().toInt()

        val result = numerator / denominator
        val remainder = numerator % denominator
        println("Result = $result remainder $remainder")
    }
    // The first matching catch block handles the exception.
    catch (error: NumberFormatException) {
        println("You didn't enter a valid number")
    }
    catch (error: IllegalArgumentException) {
        println("Illegal argument")
    }
    // This broad catch also handles division by zero; the later catch is not reached.
    catch (error: Exception) {
        println("Some sort of error occurred")
    }
    catch (error: ArithmeticException) {
        println("You tried to divide by zero")
    }
}
