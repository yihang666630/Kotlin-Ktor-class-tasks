// Task 15.3

class Student(val degree: String) : Person() {

    // Replace the inherited method with Student-specific behaviour.
    override fun speak() {
        println("I am a Student, studying $degree")
    }
}
