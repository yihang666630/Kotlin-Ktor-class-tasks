// Task 15.3

open class Person {

    // open allows a subclass to replace this implementation.
    open fun speak() {
        println("I am a Person")
    }
}
