// Task 15.3

fun main() {
    val p = Person()
    p.speak()

    val s = Student("Computer Science")
    s.speak()

    // Dynamic dispatch uses Student.speak() even through a Person reference.
    val p2: Person = Student("Maths")
    p2.speak()
}
