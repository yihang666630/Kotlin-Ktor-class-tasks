// Task 12.7

import kotlinx.datetime.LocalDate

// Only primary-constructor properties participate in generated equality and hashing.
data class Person(
    var name: String,
    val birth: LocalDate,
    var isMarried: Boolean = false
)
