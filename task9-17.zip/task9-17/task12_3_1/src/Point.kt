// Task 12.3.1

class Point(var x: Double, var y: Double) {

    // Delegate to the primary constructor with origin coordinates.
    constructor() : this(0.0, 0.0)

    // Convert Int arguments to the Double properties used by the primary constructor.
    constructor(x: Int, y: Int) : this(x.toDouble(), y.toDouble())
}
