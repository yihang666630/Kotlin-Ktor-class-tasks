// Task 12.3.1

fun main() {
    val p = Point(4.5, 7.0)
    println("(${p.x}, ${p.y})")

    // These calls select the no-argument and Int secondary constructors.
    val origin = Point()
    println("(${origin.x}, ${origin.y})")

    val q = Point(4, 7)
    println("(${q.x}, ${q.y})")
}
