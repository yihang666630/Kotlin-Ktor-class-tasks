// Task 15.4.2

import java.awt.Graphics2D

class Picture {
    private val shapes = mutableListOf<Shape>()
    fun add(shape: Shape) = shapes.add(shape)
    fun draw(context: Graphics2D) = shapes.forEach {
        // Dynamic dispatch selects the correct subclass method without type checks.
        it.draw(context)
    }
}
