// Task 15.4.2

import java.awt.Color
import java.awt.Graphics2D

open class Shape(val x: Int, val y: Int, val color: Color) {
    // The default is empty; subclasses override it with their own drawing.
    open fun draw(context: Graphics2D) {
    }
}
