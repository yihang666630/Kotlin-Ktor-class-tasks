// Task 15.2.1
open class Parent

// Child must also be open; openness is not inherited from Parent.
open class Child : Parent()
class GrandChild : Child()
