// Task 13.4

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.assertions.withClue
import io.kotest.core.spec.style.FreeSpec
import io.kotest.matchers.shouldBe

@Suppress("unused")
class MoneyTest : FreeSpec({

    "Can create a Money" {
        val m = Money(1, 50)
        withClue("euros") { m.euros shouldBe 1 }
        withClue("cents") { m.cents shouldBe 50 }
    }

    "Can create a different Money" {
        val m = Money(2, 99)
        withClue("euros") { m.euros shouldBe 2 }
        withClue("cents") { m.cents shouldBe 99 }
    }

    "Cannot create a Money with negative euros" {
        shouldThrow<IllegalArgumentException> { Money(-1, 0) }
    }

    "Cannot create a Money with negative cents" {
        shouldThrow<IllegalArgumentException> { Money(0, -1) }
    }

    "Cannot create a Money with cents greater than 99" {
        shouldThrow<IllegalArgumentException> { Money(0, 100) }
    }

    "€1.50 + €1.00 is €2.50" {
        Money(1, 50) + Money(1, 0) shouldBe Money(2, 50)
    }

    "€1.50 + €2.00 is €3.50" {
        Money(1, 50) + Money(2, 0) shouldBe Money(3, 50)
    }

    "€1.50 + €0.01 is €1.51" {
        Money(1, 50) + Money(0, 1) shouldBe Money(1, 51)
    }

    // Check that 100 cents carry into the next euro.
    "€2.99 + €0.01 is €3.00" {
        Money(2, 99) + Money(0, 1) shouldBe Money(3, 0)
    }

    // Regression cases cover intermediate overflow and the supported amount limit.
    "A large amount can be added to zero without overflowing cents" {
        Money(22_000_000, 0) + Money(0, 0) shouldBe Money(22_000_000, 0)
    }

    "The largest supported amount can be added to zero" {
        Money(Int.MAX_VALUE, 99) + Money(0, 0) shouldBe Money(Int.MAX_VALUE, 99)
    }

    "A sum beyond the supported euro range is rejected" {
        shouldThrow<IllegalArgumentException> {
            Money(Int.MAX_VALUE, 99) + Money(0, 1)
        }
    }
})
