// Task 13.4

// Value equality lets tests compare amounts directly.
data class Money(val euros: Int, val cents: Int) {

    init {
        require(euros >= 0) { "euros cannot be negative" }
        require(cents in 0..99) { "cents must be between 0 and 99" }
    }

    operator fun plus(other: Money): Money {
        // Use Long for intermediate cents to avoid Int multiplication overflow.
        val totalCents = euros.toLong() * 100 + cents + other.euros.toLong() * 100 + other.cents
        val totalEuros = totalCents / 100
        // Reject sums that cannot fit in the euros property.
        require(totalEuros <= Int.MAX_VALUE.toLong()) { "Total euros exceed the supported range" }
        // Convert total cents back into euros and a remainder in 0..99.
        return Money(totalEuros.toInt(), (totalCents % 100).toInt())
    }
}
