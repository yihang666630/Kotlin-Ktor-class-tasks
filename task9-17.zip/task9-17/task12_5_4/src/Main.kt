// Task 12.5.4

import kotlinx.datetime.LocalDate

fun main() {
    val person = Person("Alice Smith", LocalDate(2000, 1, 1))

    // Accessing age invokes its computed-property getter.
    println("${person.name} is ${person.age} years old")
}
