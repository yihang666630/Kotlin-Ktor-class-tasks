// Task 12.5.4

import kotlin.time.Clock
import kotlinx.datetime.LocalDate
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime

fun today(zone: TimeZone = TimeZone.currentSystemDefault()): LocalDate {
    val now = Clock.System.now()
    // Convert the current instant to the date in the requested time zone.
    return now.toLocalDateTime(zone).date
}
