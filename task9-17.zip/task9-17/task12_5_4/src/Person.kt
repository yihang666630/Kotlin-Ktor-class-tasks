// Task 12.5.4

import kotlinx.datetime.LocalDate
import kotlinx.datetime.yearsUntil

class Person(var name: String, val birth: LocalDate) {
    var isMarried = false

    // Recalculate completed years on each access; no age field is stored.
    val age get() = birth.yearsUntil(today())
}
