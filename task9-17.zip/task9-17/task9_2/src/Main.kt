// Task 9.2

fun main() {
    println("Entered main()")
    first()
    println("Leaving main()")
}

fun first() {
    println("Entered first()")
    second()
    println("Leaving first()")
}

fun second() {
    println("Entered second()")
    val data = listOf(1, 2, 3, 4, 5)
    // Intentional error: index 5 is invalid, so the Leaving messages never run.
    println(data[5])
    println("Leaving second()")
}
