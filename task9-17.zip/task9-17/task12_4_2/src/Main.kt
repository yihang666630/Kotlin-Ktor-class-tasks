// Task 12.4.2

fun main() {
    val p = Point(4.5, 7.0)
    // println() automatically uses the overridden toString().
    println(p)
}
