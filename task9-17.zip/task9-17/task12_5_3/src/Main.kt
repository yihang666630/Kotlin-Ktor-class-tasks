// Task 12.5.3

import kotlinx.datetime.LocalDate

fun main() {
    val person = Person("Alice Smith", LocalDate(1997, 8, 23))
    println("Initial name: ${person.name}")

    // Intentional uncaught exception: inspect the setter traceback as the guide requests.
    person.name = ""
}
