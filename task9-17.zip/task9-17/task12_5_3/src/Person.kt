// Task 12.5.3

import kotlinx.datetime.LocalDate

class Person(_name: String, val birth: LocalDate) {
    var isMarried = false

    // Property initialization does not call the custom setter.
    var name = _name
        // Validate later assignments before updating the backing field.
        set(value) {
            require(value.isNotBlank()) { "Name cannot be blank" }
            field = value
        }
}
