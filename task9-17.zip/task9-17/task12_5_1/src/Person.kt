// Task 12.5.1

import kotlinx.datetime.LocalDate

// var generates a getter and setter; val generates only a getter.
class Person(var name: String, val birth: LocalDate) {
    var isMarried = false
}
