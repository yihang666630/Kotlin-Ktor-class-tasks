// Task 12.3.2

import kotlinx.datetime.LocalDate

class Person(var name: String, val birth: LocalDate) {
    var isMarried = false

    // Parse the ISO date before delegating to the primary constructor.
    constructor(name: String, birthDate: String) : this(name, LocalDate.parse(birthDate))
}
