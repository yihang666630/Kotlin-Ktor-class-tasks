// Task 12.3.2

fun main() {
    // The String argument selects the date-parsing secondary constructor.
    val person = Person("Alice Smith", "1997-08-23")

    println("Name: ${person.name}")
    println("Date of birth: ${person.birth}")
    println("Married: ${person.isMarried}")
}
