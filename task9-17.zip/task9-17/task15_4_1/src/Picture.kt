// Task 15.4.1

import java.awt.Graphics2D

class Picture {
    private val shapes = mutableListOf<Shape>()
    fun add(shape: Shape) = shapes.add(shape)
    fun draw(context: Graphics2D) = shapes.forEach { shape ->
        // This initial version checks types before invoking subclass-only draw methods.
        when {
            shape is Circle -> shape.draw(context)
            shape is Rectangle -> shape.draw(context)
        }
    }
}
