// Task 15.4.1
import java.awt.Color

// Store the position and colour shared by shape subclasses.
open class Shape(val x: Int, val y: Int, val color: Color)
