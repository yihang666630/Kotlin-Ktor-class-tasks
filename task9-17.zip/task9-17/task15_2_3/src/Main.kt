// Task 15.2.3

fun main() {
    val account = SavingsAccount("Alice Smith", 1.8)

    account.deposit(1250)

    // Apply interest once per year, including interest from earlier years.
    repeat(5) { account.applyInterest() }

    account.withdraw(50)

    println("Final balance: £${account.balance}")
}
