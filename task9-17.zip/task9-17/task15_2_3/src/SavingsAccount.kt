// Task 15.2.3

class SavingsAccount(holder: String, val rate: Double) : BankAccount(holder) {

    init {
        require(rate > 0) { "Interest rate must be greater than 0" }
    }

    fun applyInterest() {
        // Treat rate as a percentage of the current balance.
        val interest = balance * rate / 100
        // Keep the task's whole-pound amounts by truncating fractional interest.
        val wholePounds = interest.toInt()
        // Skip zero interest because deposit() only accepts positive amounts.
        if (wholePounds > 0) {
            deposit(wholePounds)
        }
    }
}
