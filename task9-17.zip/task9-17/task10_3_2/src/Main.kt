// Task 10.3.2

import kotlin.system.exitProcess

// Accept nullable input and handle the missing translation inside display().
fun display(text: String?) {
    when (text) {
        null -> println("?")
        else -> println(text.uppercase())
    }
}

fun main(args: Array<String>) {
    if (args.size != 1) {
        println("Single word required as a command line argument")
        exitProcess(1)
    }

    val translate = loadDatabase("en-to-fr.csv")

    val word = args[0].lowercase()
    val result = translate[word]

    display(result)
}
