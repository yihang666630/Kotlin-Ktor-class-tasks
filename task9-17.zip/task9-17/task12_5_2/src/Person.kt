// Task 12.5.2

import kotlinx.datetime.LocalDate

class Person(_name: String, val birth: LocalDate) {

    var isMarried = false

    var name = _name
        get() {
            // Read the backing field to avoid calling this getter recursively.
            return field.uppercase()
        }
}
