// Task 12.5.2

import kotlinx.datetime.LocalDate

fun main() {
    val person = Person("alice SMITH", LocalDate(1997, 8, 23))

    // The getter presents the stored name in uppercase.
    println(person.name) // ALICE SMITH
}
