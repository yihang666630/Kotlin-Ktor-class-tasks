// Task 12.8.2

class Card(val rank: Rank, val suit: Suit) {

    // Use enum names for readable text rather than their overridden symbol strings.
    val fullName get() = "${rank.name} of ${suit.name}"

    // Combine the rank and suit symbols into the short form.
    override fun toString() = "${rank.symbol}${suit.symbol}"
}
