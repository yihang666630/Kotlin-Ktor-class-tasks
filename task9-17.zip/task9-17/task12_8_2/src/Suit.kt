// Task 12.8.2

enum class Suit(val symbol: Char) {
    Clubs('♣'),
    Diamonds('♦'),
    Hearts('♥'),
    Spades('♠');

    // Use the first letter when a Unicode suit symbol is unsuitable.
    val plainSymbol get() = name[0]

    override fun toString() = "$symbol"
}
