// Task 12.8.2

fun main() {
    val deck = mutableListOf<Card>()

    // All 4 suits and 13 ranks form 52 distinct cards.
    for (suit in Suit.entries) {
        for (rank in Rank.entries) {
            deck.add(Card(rank, suit))
        }
    }

    deck.shuffle()

    for (card in deck) {
        println(card.fullName)
    }
}
