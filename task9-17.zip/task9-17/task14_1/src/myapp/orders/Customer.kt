// Task 14.1

// The package name matches the source directory structure.
package myapp.orders

data class Customer(val name: String, val email: String)
