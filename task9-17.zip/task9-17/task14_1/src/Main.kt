// Task 14.1

// Import the class from its named package.
import myapp.orders.Customer

fun main() {
    val customer = Customer("Joe Smith", "joe@example.com")
    println(customer)
}
