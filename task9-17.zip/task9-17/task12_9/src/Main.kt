// Task 12.9

import kotlinx.datetime.LocalDate

fun main() {
    val first = Person.create("Sarah", LocalDate(2005, 7, 16))
    println("Created: ${first.name}, born ${first.birth}")

    // The factory rejects a second person with the same name.
    val duplicate = runCatching { Person.create("Sarah", LocalDate(2007, 1, 2)) }
    println("Duplicate-name attempt failed with: ${duplicate.exceptionOrNull()}")
}
