// Task 12.9

import kotlinx.datetime.LocalDate

// A private constructor forces callers to use the factory.
class Person private constructor(val name: String, val birth: LocalDate) {
    companion object Factory {
        // The companion object shares the set of used names across all instances.
        private val names = mutableSetOf<String>()
        fun create(name: String, birth: LocalDate): Person {
            // Reserve each name once before returning a new person.
            require(name !in names) { "Name must be unique!" }
            names.add(name)
            return Person(name, birth)
        }
    }
}
