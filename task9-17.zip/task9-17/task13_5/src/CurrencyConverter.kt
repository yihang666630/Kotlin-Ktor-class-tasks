// Task 13.5

// Inject the service so tests can supply a stub instead of a network dependency.
class CurrencyConverter(val service: ExchangeRateService) {
    fun convertTo(currency: String, amount: Double): Double {
        return service.rateFor(currency) * amount
    }
}
