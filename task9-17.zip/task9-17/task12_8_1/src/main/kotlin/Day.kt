// Task 12.8.1

// Restrict day values to these seven named constants.
enum class Day {
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday,
    Sunday
}
