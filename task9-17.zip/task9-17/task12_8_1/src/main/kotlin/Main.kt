// Task 12.8.1

fun main() {
    print("Enter a day of the week: ")
    val input = readln().trim()

    try {
        // valueOf() is case-sensitive and throws for unknown names.
        val day = Day.valueOf(input)
        println("You entered: $day")
    } catch (error: IllegalArgumentException) {
        println("'$input' is not a valid day.")
        // entries lists every valid enum constant.
        println("Options are: ${Day.entries.joinToString()}")
    }
}
