// Task 9.6

import kotlin.io.path.Path
import kotlin.io.path.forEachLine

// Read one Double per line; invalid data throws a parsing exception.
fun readData(filename: String) = buildList {
    Path(filename).forEachLine {
        add(it.toDouble())
    }
}
