// Task 9.6

import kotlin.system.exitProcess

fun main(args: Array<String>) {
    if (args.size != 1) {
        println("Usage: kotlin run <data-file>")
        exitProcess(1)
    }

    // Catch file, parsing and data-validation errors in one place.
    val outcome = runCatching {
        val data = readData(args[0])
        val result = variance(data)
        println("Dataset size: ${data.size}")
        println("Variance: ${"%.5f".format(result)}")
    }

    // Report the error and return a non-zero exit status.
    if (outcome.isFailure) {
        println("An error occurred: ${outcome.exceptionOrNull()}")
        exitProcess(1)
    }
}
