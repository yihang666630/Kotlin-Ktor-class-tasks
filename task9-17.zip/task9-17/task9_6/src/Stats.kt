// Task 9.6

fun variance(dataset: List<Double>): Double {
    // Sample variance requires at least two values.
    require(dataset.size > 1) { "not enough data" }

    val mean = dataset.average()
    // Sum squared deviations, then divide by n - 1 for sample variance.
    val sumSquaredDeviations = dataset.map { it - mean }.sumOf { it * it }
    return sumSquaredDeviations / (dataset.size - 1)
}
