// Task 16.2

abstract class Vehicle(var fuelLevel: Int) {
    fun refuel(amount: Int) {
        require(amount >= 0) { "Invalid fuel amount" }
        fuelLevel += amount
    }
    // Concrete subclasses must implement this method.
    abstract fun drive()
}
