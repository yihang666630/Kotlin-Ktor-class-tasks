// Task 16.2

fun main() {
    // Instantiate the concrete Car rather than the abstract Vehicle.
    val car = Car(50)
    car.drive()
}
