// Task 16.2

class Car(fuel: Int) : Vehicle(fuel) {
    // Implementing drive() makes Car concrete and instantiable.
    override fun drive() {
        println("Vrooom!")
    }
}
