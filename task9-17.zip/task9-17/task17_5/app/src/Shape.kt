// Task 17.5

import java.awt.Color
// Keep shared shape data here; Drawable defines the drawing contract.
abstract class Shape(val x: Int, val y: Int, val color: Color)
