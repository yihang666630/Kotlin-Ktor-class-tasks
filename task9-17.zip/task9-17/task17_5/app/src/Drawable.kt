// Task 17.5

import java.awt.Graphics2D

interface Drawable {
    // Any drawable object must support this Graphics2D operation.
    fun draw(context: Graphics2D)
}
