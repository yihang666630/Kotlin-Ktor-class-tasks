// Task 12.4.1

import kotlin.math.hypot

class Point(val x: Double, val y: Double) {
    // hypot(x, y) calculates the distance from the origin.
    fun distance() = hypot(x, y)
    // Apply Pythagoras to the difference between the two coordinates.
    fun distanceTo(p: Point) = hypot(x - p.x, y - p.y)
}
