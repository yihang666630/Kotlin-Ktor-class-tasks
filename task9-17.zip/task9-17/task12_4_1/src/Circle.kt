// Task 12.4.1

import kotlin.math.PI

class Circle(val centre: Point, val radius: Double) {

    // Reject zero and negative radii during construction.
    init {
        require(radius > 0) { "Radius must be greater than zero" }
    }

    fun area() = PI * radius * radius

    fun perimeter() = 2 * PI * radius

    // Points on the boundary count as inside.
    infix fun contains(point: Point) = centre.distanceTo(point) <= radius
}
