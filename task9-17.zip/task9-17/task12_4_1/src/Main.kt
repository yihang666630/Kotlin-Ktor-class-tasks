// Task 12.4.1

fun main() {
    val circle = Circle(Point(0.0, 0.0), 5.0)

    println("Area: ${"%.4f".format(circle.area())}")
    println("Perimeter: ${"%.4f".format(circle.perimeter())}")

    // Use a boundary point and an outside point to check contains().
    val onEdge = Point(3.0, 4.0)
    val outside = Point(6.0, 8.0)
    println("Point (3, 4) inside? ${circle contains onEdge}")
    println("Point (6, 8) inside? ${circle contains outside}")

    val bad = runCatching { Circle(Point(0.0, 0.0), -2.0) }
    println("Negative-radius attempt: ${bad.exceptionOrNull()}")
}
