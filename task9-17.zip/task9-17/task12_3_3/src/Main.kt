// Task 12.3.3

fun main() {
    val valid = Person("Alice Smith", "1997-08-23")
    println("Created: ${valid.name}")

    // Capture invalid-name errors so both empty and spaces-only cases can be shown.
    val emptyResult = runCatching { Person("", "1997-08-23") }
    println("Empty-name attempt failed with: ${emptyResult.exceptionOrNull()}")

    val spacesResult = runCatching { Person("   ", "1997-08-23") }
    println("Spaces-only attempt failed with: ${spacesResult.exceptionOrNull()}")
}
