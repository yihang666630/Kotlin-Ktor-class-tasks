// Task 17.3

fun main() {
    // An interface reference can invoke the concrete Document implementation.
    val item: Printable = Document("info.txt")
    item.print()
}
