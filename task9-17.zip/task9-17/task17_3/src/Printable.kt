// Task 17.3

interface Printable {
    // Implementing classes must provide this operation.
    fun print()
}
