// Task 17.3

class Document(val filename: String) : Printable {
    // Fulfil the Printable contract with a filename message.
    override fun print() {
        println("Printing $filename")
    }
}
