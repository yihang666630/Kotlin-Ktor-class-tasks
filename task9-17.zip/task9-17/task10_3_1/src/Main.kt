// Task 10.3.1

import kotlin.system.exitProcess

fun display(text: String) {
    println(text.uppercase())
}

fun main(args: Array<String>) {
    if (args.size != 1) {
        println("Single word required as a command line argument")
        exitProcess(1)
    }

    val translate = loadDatabase("en-to-fr.csv")

    val word = args[0].lowercase()
    val result = translate[word]

    // The non-null branch smart-casts result to String before calling display().
    when (result) {
        null -> println("?")
        else -> display(result)
    }
}
