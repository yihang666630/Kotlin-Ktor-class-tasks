// Task 12.1

import kotlin.math.hypot

class Point(var x: Double, var y: Double) {

    // hypot(x, y) calculates the distance from the origin.
    fun distance() = hypot(x, y)

    // Apply Pythagoras to the difference between the two coordinates.
    fun distanceTo(p: Point) = hypot(p.x - x, p.y - y)
}
