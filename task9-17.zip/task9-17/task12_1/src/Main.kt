// Task 12.1

fun main() {
    val p = Point(3.0, 4.0)

    println("Point is at (${p.x}, ${p.y})")

    println("Distance from origin: ${p.distance()}")

    // Compare the chosen point with the fixed point required by the task.
    val q = Point(4.5, 7.0)
    println("Distance to (4.5, 7.0): ${p.distanceTo(q)}")
}
