# Python equivalent of the Kotlin Point example.

import math

class Point:
    """A point in 2D space with mutable x and y coordinates."""

    def __init__(self, x, y):
        self.x = x
        self.y = y

    def distance(self):
        """Distance of this point from the origin."""
        return math.hypot(self.x, self.y)

    def distance_to(self, other):
        """Distance from this point to another Point."""
        return math.hypot(other.x - self.x, other.y - self.y)
