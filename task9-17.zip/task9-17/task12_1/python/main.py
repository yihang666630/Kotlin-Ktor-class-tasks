# Python equivalent of the Kotlin Point example.

from point import Point

def main():
    p = Point(3.0, 4.0)

    print(f"Point is at ({p.x}, {p.y})")

    print(f"Distance from origin: {p.distance()}")

    q = Point(4.5, 7.0)
    print(f"Distance to (4.5, 7.0): {p.distance_to(q)}")

if __name__ == "__main__":
    main()
