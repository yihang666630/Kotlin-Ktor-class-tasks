// Task 10.1

import kotlin.io.path.Path
import kotlin.io.path.forEachLine

// Build a word-to-translation map from the CSV file.
fun loadDatabase(filename: String) = buildMap {
    Path(filename).forEachLine {
        val parts = it.split(",")
        put(parts[0].trim(), parts[1].trim())
    }
}
