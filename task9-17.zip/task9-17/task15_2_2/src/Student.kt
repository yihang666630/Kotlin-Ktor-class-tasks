// Task 15.2.2

// Pass name to Person; degree is the property added by Student.
class Student(name: String, val degree: String): Person(name) {
    init {
        println("Student constructor invoked")
    }
}
