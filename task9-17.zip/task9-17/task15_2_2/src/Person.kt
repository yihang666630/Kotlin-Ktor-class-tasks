// Task 15.2.2

open class Person(val name: String) {
    // Superclass initialization runs before the Student initializer.
    init {
        println("Person constructor invoked")
    }
}
