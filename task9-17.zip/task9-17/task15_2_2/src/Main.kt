// Task 15.2.2

fun main() {
    // Creating Student first initializes its Person superclass.
    val student = Student("Sarah", "Computer Science")
    println(student.name)
    println(student.degree)
}
