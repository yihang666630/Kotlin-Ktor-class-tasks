// Task 16.3
import java.awt.Color
import java.awt.Graphics2D
import java.awt.geom.Ellipse2D
class Circle(x: Int, y: Int, val radius: Int, color: Color) : Shape(x, y, color) {
    override fun draw(context: Graphics2D) {
        val size = 2.0f * radius
        // Convert centre/radius coordinates to the bounding box expected by Ellipse2D.
        val cornerX = (x - radius).toFloat()
        val cornerY = (y - radius).toFloat()
        val shape = Ellipse2D.Float(cornerX, cornerY, size, size)

        // Fill in the shape colour, outline in black, then restore the previous paint.
        val oldColor = context.paint
        context.paint = color
        context.fill(shape)
        context.paint = Color.BLACK
        context.draw(shape)
        context.paint = oldColor
    }
}
