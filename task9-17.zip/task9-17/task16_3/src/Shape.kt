// Task 16.3

import java.awt.Color
import java.awt.Graphics2D
abstract class Shape(val x: Int, val y: Int, val color: Color) {
    // Every concrete shape must provide its own drawing implementation.
    abstract fun draw(context: Graphics2D)
}
