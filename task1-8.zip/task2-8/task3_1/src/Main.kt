// Task 3.1: processing command line arguments

// Import the exitProcess function from kotlin.system
import kotlin.system.exitProcess

// main() receives the command line arguments in an Array<String>
fun main(args: Array<String>) {

    if (args.size != 2) {

        println("Error: two command line arguments are required")

        exitProcess(1)
    }
    println(args[0])
    println(args[1])
}


