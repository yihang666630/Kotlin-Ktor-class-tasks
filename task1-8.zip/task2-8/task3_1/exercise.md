Consider the following Kotlin program:

fun main() {
println("Hello World!")
}

Imagine that this is part of a Kotlin Toolchain project. What happens if we try to run the program like this?

./kotlin run xxx

1. The program prints “Hello World! xxx”

2. The program fails to compile because the parameter list of main() is empty

3. The program fails with a runtime error because the parameter list of main() is empty

4. The program prints “Hello World!”, ignoring the command line argument

4 is correct, Command line arguments can be supplied to a program even if it hasn’t been equipped to process them. 
Giving main() a parameter of type Array<String> gives you access to those arguments if you need them, 
but you don’t have to declare a parameter if you don’t need to use them in your program.