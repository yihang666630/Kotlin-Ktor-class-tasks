// Task 8.4.1: experimenting with sequences

fun main() {
    // A small list of integers to process
    val numbers = listOf(1, 4, 7, 2, 9, 3, 8)

    // Build a pipeline of operations on the list:
    val result = numbers
        .asSequence()                // turn the list into a lazy sequence
        .filter { it % 2 != 0 }      // keep only the odd values: 1, 7, 9, 3
        .map { it * it }             // square each kept value
        .toList()                    // materialise the sequence into a list

    println(result)                  // [1, 49, 81, 9]
}
