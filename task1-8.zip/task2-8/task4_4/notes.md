1. Kotlin is stricter than C with regard to the test that follows the while keyword. This test must yield a boolean result (as an expression)
2. Kotlin also has "do...while" loop
3. Remember that a while loop will not execute at all if the test associated with the while evaluates to false immediately, whereas a do...while loop is guaranteed to execute at least once, because the test is done at the end rather than the start.
while: first test/examine, then execute
that said: when test False --> 0 execution

do...while:
// do...while: 先执行再检查 → 至少执行一次
do {
println("do-while: $x")  // ← 打印 "do-while: 10"
} while (x < 5)
first execute, then test/examine
that said, the program at least execute once if test is False.
