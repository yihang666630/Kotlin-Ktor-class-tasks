// Task 4.4: Celsius to Fahrenheit conversion using a while loop
// (Option 1: plain console output with two right-aligned columns)

import kotlin.system.exitProcess

fun main(args: Array<String>) {
    if (args.size != 3) {
        println("Error: three parameter values need to be provided!")
        exitProcess(1)
    }

    val invalidArg = args.firstOrNull { it.toDoubleOrNull() == null }
    if (invalidArg != null) {
        // Report the first non-numeric argument and stop
        println("Error: '$invalidArg' is not a valid number! Please enter numeric values.")
        exitProcess(1)
    }

    var initialTempC = args[0].toFloat()
    val maxTempC = args[1].toFloat()
    val incrementC = args[2].toFloat()

    while (initialTempC <= maxTempC) {
        val tempF = initialTempC * 1.8f + 32f
        println("%6.1f %6.1f".format(initialTempC, tempF))
        // Move on to the next temperature in the series
        initialTempC += incrementC
    }
}
