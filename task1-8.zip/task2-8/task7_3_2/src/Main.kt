// Task 7.3.2: demonstrating the modification methods of a mutable list

fun main() {
    // Create a mutable list of integers (created with mutableListOf())
    val numbers = mutableListOf(9, 3, 6, 2, 8, 5)

    println(numbers)

    // add(value): append a value to the end of the list
    numbers.add(10)
    println("After add(10): $numbers")

    // add(index, value): insert a value at a specific position
    numbers.add(0, 1)
    println("After add(0, 1): $numbers")

    // set(index, value): replace the value at a specific position
    numbers.set(2, 99)
    println("After set(2, 99): $numbers")

    // remove(value): remove the first occurrence of the given value
    numbers.remove(3)
    println("After remove(3): $numbers")

    // removeAt(index): remove the value at a specific position
    numbers.removeAt(1)
    println("After removeAt(1): $numbers")

    // addAll(collection): append several values at once
    numbers.addAll(listOf(7, 11))
    println("After addAll(listOf(7, 11)): $numbers")

    // removeAll(collection): remove every occurrence of the given values
    numbers.removeAll(listOf(2, 11))
    println("After removeAll(listOf(2, 11)): $numbers")

    // clear(): remove all values from the list
    numbers.clear()
    println("After clear(): $numbers")
}
