// Task 5.3.1: main program that uses the default number of die sides

fun main(args: Array<String>) {
    if (args.isEmpty()) {
        rollDie() //default value
    }
    else {
        rollDie(args[0].toInt())
    }
}
