// Task 4.8: demonstration of the BAD approach to building strings iteratively
// (Repeated string concatenation creates many intermediate String objects.)

// Import exitProcess for terminating with an error status
import kotlin.system.exitProcess
// Import measureTime to time the execution of a block of code
import kotlin.time.measureTime

fun main(args: Array<String>) {
    // The program requires exactly one command line argument
    if (args.size != 1) {
        // Print an error message when the limit is missing
        println("Error: missing command line argument!")
        exitProcess(1)
    }

    // Read the upper limit for the loop as an Int
    val limit = args[0].toInt()

    // Measure how long the string-building loop takes
    val time = measureTime {
        // Start with an empty string
        var result = ""
        // Append each number and a separating comma to the string
        for (n in 1..limit) {
            // Concatenate the number onto the growing string (a new String is created)
            result += n
            // Add a comma between numbers (but not after the last one)
            if (n < limit) {
                result += ','
            }
        }
    }

    // Display the time taken by the bad approach
    println("Bad approach: $time")
}
