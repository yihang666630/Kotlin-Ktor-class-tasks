// Task 4.8: demonstration of the GOOD approach to building strings iteratively
// (buildString() uses a StringBuilder, avoiding repeated object creation.)

// Import exitProcess for terminating with an error status
import kotlin.system.exitProcess
// Import measureTime to time the execution of a block of code
import kotlin.time.measureTime

fun main(args: Array<String>) {
    // The program requires exactly one command line argument
    if (args.size != 1) {
        // Print an error message when the limit is missing
        println("Error: missing command line argument!")
        exitProcess(1)
    }

    // Read the upper limit for the loop as an Int
    val limit = args[0].toInt()

    // Measure how long the string-building loop takes
    val time = measureTime {
        // buildString() provides a StringBuilder as the receiver of the lambda
        val result = buildString {
            // Append each number to the shared buffer (no new String per step)
            for (n in 1..limit) {
                append(n)
                // Add a comma between numbers (but not after the last one)
                if (n < limit) {
                    append(',')
                }
            }
        }
    }

    // Display the time taken by the good approach
    println("Good approach: $time")
}
