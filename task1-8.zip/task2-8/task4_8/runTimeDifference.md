PS C:\Users\23064\Desktop\tasks\task4_8> .\kotlin run -m bad 20
00:05.491 INFO  :bad:compileJvm           Compiling module 'bad' for platform 'jvm'...
Bad approach: 14.388700ms
00:09.839 INFO  :bad:runJvm               Process exited with exit code 0
PS C:\Users\23064\Desktop\tasks\task4_8> .\kotlin run -m good 20
00:02.650 INFO  :good:compileJvm          Compiling module 'good' for platform 'jvm'...
Good approach: 507.6us
00:06.839 INFO  :good:runJvm              Process exited with exit code 0