// Task 2.4: demonstrating the difference between val and var
// A val can only be assigned once; a var can be reassigned as many times as needed.

fun main() {
    var a = 10
    println(a)
    a = 12
    println(a)
}


