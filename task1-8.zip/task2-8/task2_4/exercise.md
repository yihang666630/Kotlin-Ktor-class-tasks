Here are three different situations in which we would need to use a variable. In each case, decide whether the variable should be defined as a val or as a var.

1. Representing the final result of a calculation
final result --> fixed/unchanged, using 'val'

2. Representing a sum that we compute for values in an array
in program, we use loop to obtain the sum of arrays, meaning 
sum will change after every loop. we need editable variable type --> 'var'

3. Representing input captured from the program user
in general, 'val' represent user's input, cause there's no change after user inputs sth
but some situations, like we need clean, format and amend the user's input, 'var' is used.