1. When you define a variable with val, you are allowed to assign a value to it once, 
and once only. Any subsequent attempt at assignment will cause a compile-time error.
2. When you define a variable with var, 
you can assign a value to it as many times as you like.

3. PS C:\Users\23064\Desktop\tasks\task2_4> .\kotlin build
   00:02.440 INFO  :task2_4:compileJvm       Compiling module 'task2_4' for platform 'jvm'...
   ERROR (task2_4) file:///C:/Users/23064/Desktop/tasks/task2_4/src/Main.kt:5:5 'val' cannot be reassigned.

ERROR: Task ':task2_4:compileJvm' failed: Kotlin compilation failed with 1 errors (see above)
Pay attention to the error massage about 'val' variable

4. The recommended approach in Kotlin is to define variables using val wherever you can. 
Use var only in places where a variable will need to be reassigned a value after it has initially been created.

5. Don’t think that using val is the same as defining a constant in your code!
When you use val, all you are doing is establishing a permanent link between an object and the name 
that you want to use to refer to that object.
The compiler will stop you associating the name with a different object,
   but it won’t stop that object from changing its state, should that be possible for the object in question.