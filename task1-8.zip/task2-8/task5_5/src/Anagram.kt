// Task 5.5: anagramOf() as an infix extension function of String

// Infix extension function: `word1 anagramOf word2` checks whether the two
// words are anagrams of each other (ignoring spaces and letter case)
infix fun String.anagramOf(other: String): Boolean {
    // Sort the characters of the receiver string (lowercased, spaces removed)
    val firstSorted = this.lowercase().replace(" ", "").toCharArray().apply { sort() }
    // Sort the characters of the argument string (lowercased, spaces removed)
    val secondSorted = other.lowercase().replace(" ", "").toCharArray().apply { sort() }

    // The two strings are anagrams if their sorted character arrays match
    return firstSorted.contentEquals(secondSorted)
}
