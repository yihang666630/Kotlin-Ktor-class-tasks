// Task 5.5: main program using infix notation to test for anagrams

import kotlin.system.exitProcess

fun main(args: Array<String>) {
    if (args.size != 2) {
        println("Usage: <program> <word1> <word2>")
        exitProcess(1)
    }

    // Use infix notation to test whether the second argument is an anagram of the first
    if (args[1] anagramOf args[0]) {
        println("${args[0]} and ${args[1]} are anagrams!")
    }
    else {
        println("${args[0]} and ${args[1]} are NOT anagrams.")
    }
}
