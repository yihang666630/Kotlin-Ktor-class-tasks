// Task 4.3: computing a module grade from three marks using a when expression

// Import exitProcess for terminating with an error status
import kotlin.system.exitProcess
// Import roundToInt for rounding a Double to the nearest Int
import kotlin.math.roundToInt

fun main(args: Array<String>) {

    if (args.size != 3) {
        println("Error: you need to provide 3 grades!")
        exitProcess(1)
    }

    // Find the first argument that is not a valid number, if there is one
    val invalidArg = args.firstOrNull { it.toDoubleOrNull() == null }
    if (invalidArg != null) {
        // Report the invalid argument and stop the program
        println("Error: '$invalidArg' is not a valid number! Please enter numeric grades.")
        exitProcess(1)
    }

    val marks = args.map { it.toDouble() }

    val roundAvg = marks.average().roundToInt()

    val grade = when (roundAvg) {
        in 0..39 -> "$roundAvg Fail"
        in 40..69 -> "$roundAvg Pass"
        else -> "$roundAvg Invalid"
    }

    // Display the computed grade
    println(grade)
}
