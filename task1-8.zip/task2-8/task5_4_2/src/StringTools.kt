// Task 5.4.2: isTooLong as an extension property instead of a function

// Extension property: its value is recomputed every time it is accessed
val String.isTooLong: Boolean
    // The getter returns true if the receiver string is longer than 20 characters
    get() = this.length > 20
