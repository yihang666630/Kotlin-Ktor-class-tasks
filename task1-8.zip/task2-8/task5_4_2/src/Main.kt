// Task 5.4.2: main program that tests the isTooLong extension property

fun main() {
    val shortString = "Hello"
    val exactString = "12345678901234567890"
    val longString = "This string is definitely too long!"

    // Access the property; note that a property is used without parentheses
    println("\"$shortString\" isTooLong: ${shortString.isTooLong}")   // false
    println("\"$exactString\" isTooLong: ${exactString.isTooLong}")   // false
    println("\"$longString\" isTooLong: ${longString.isTooLong}")     // true
}
