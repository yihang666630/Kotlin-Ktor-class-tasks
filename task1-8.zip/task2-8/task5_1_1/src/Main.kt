// Task 5.1.1: main program that tests the anagrams() function

import kotlin.system.exitProcess

fun main(args: Array<String>) {
    if (args.size != 2) {
        println("Error: you need to offer two words")
        exitProcess(1)
    }

    // Compare the two words using the anagrams() function
    // (it is a top-level function, so no import is needed to call it)
    val result = anagrams(args[0], args[1])

    if (result) {
        println("'${args[0]}' and '${args[1]}' are anagrams!")
    }
    else {
        println("'${args[0]}' and '${args[1]}' are NOT anagrams.")
    }
}
