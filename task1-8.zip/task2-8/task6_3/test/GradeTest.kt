// Task 6.3: unit tests for the grade() function using kotlin.test

// Import the Test annotation and the assertEquals assertion function
import kotlin.test.Test
import kotlin.test.assertEquals

// The test class that groups all of the grade() tests
class GradeTest {
    // A mark of 0 should be at the bottom of the Fail range
    @Test
    fun `Mark of 0 gives a Fail`() {
        assertEquals("Fail", grade(0))
    }

    // A mark of 20 should be inside the Fail range
    @Test
    fun `Mark of 20 gives a Fail`() {
        assertEquals("Fail", grade(20))
    }

    // A mark of 39 should be at the top of the Fail range
    @Test
    fun `Mark of 39 gives a Fail`() {
        assertEquals("Fail", grade(39))
    }

    // A mark of 40 should be at the bottom of the Pass range
    @Test
    fun `Mark of 40 gives a Pass`() {
        assertEquals("Pass", grade(40))
    }

    // A typical mark inside the Pass range
    @Test
    fun `Mark of 55 gives a Pass`() {
        assertEquals("Pass", grade(55))
    }

    // A mark of 69 should be at the top of the Pass range
    @Test
    fun `Mark of 69 gives a Pass`() {
        assertEquals("Pass", grade(69))
    }

    // A mark of 70 should be at the bottom of the Distinction range
    @Test
    fun `Mark of 70 gives a Distinction`() {
        assertEquals("Distinction", grade(70))
    }

    // A typical mark inside the Distinction range
    @Test
    fun `Mark of 85 gives a Distinction`() {
        assertEquals("Distinction", grade(85))
    }

    // A mark of 100 should be at the top of the Distinction range
    @Test
    fun `Mark of 100 gives a Distinction`() {
        assertEquals("Distinction", grade(100))
    }

    // A negative mark is not a valid grade
    @Test
    fun `Mark of -1 isn't a valid grade`() {
        assertEquals("?", grade(-1))
    }

    // A negative mark is not a valid grade
    @Test
    fun `Mark of -5 isn't a valid grade`() {
        assertEquals("?", grade(-5))
    }

    // A mark above 100 is not a valid grade
    @Test
    fun `Mark of 101 isn't a valid grade`() {
        assertEquals("?", grade(101))
    }

    // A mark above 100 is not a valid grade
    @Test
    fun `Mark of 105 isn't a valid grade`() {
        assertEquals("?", grade(105))
    }
}
