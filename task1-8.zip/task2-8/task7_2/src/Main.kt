// Task 7.2: exploring the difference between arrayOf() and intArrayOf()

fun main() {

    val numbers = arrayOf(9, 6, 3, 2)
    // Get a reference to the runtime class of the array
    val cls = numbers::class

    println(cls.qualifiedName)
    println(cls.java)

}
