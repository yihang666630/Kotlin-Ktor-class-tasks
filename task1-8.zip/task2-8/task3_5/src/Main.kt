// Task 3.5: simple file I/O using the kotlin.io.path API
// On the JVM you have access to the java.io and java.nio APIs, and Kotlin
// layers its own kotlin.io.path extensions on top of them.

// Import the Path class and its writeText/appendText/readText extensions
import kotlin.io.path.Path
import kotlin.io.path.appendText
import kotlin.io.path.readText
import kotlin.io.path.writeText

fun main() {
    // create a Path object referring to the file "test.txt"
    val filePath = Path("test.txt")
    filePath.writeText("Hello world!")
    filePath.writeText("911")
    filePath.appendText(" Hello world!")
    val text = filePath.readText()
    print(text)
}
