// Task 7.3.1: exploring element access on an immutable list

fun main() {
    // Create an immutable list of integers (created with listOf())
    val numbers = listOf(9, 3, 6, 2, 8, 5)

    println(numbers)

    println(numbers[0])

    println(numbers.slice(2..4))     //    i.e. the values [6, 2, 8]

    println(numbers.first())   // 9
    println(numbers.last())    // 5

}
