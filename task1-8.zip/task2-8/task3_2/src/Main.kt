// Task 3.2: converting a command line argument to a number

// Import the exitProcess function from kotlin.system
import kotlin.system.exitProcess

// main() receives the command line arguments in an Array<String>
fun main(args: Array<String>) {
    // The program expects exactly one command line argument
    if (args.size != 1) {
        println("Error: integer required on command line")
        exitProcess(1)
    }

    val number = args[0].toInt() // Int
    // Print the square of the number; note that a large value such as 92682
    // overflows the Int range and therefore produces an incorrect result
    println(number * number)
}
