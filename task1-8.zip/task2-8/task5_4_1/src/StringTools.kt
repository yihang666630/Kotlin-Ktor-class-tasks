// Task 5.4.1: an extension function for the String class

// Extension function: return true if the receiver string is longer than 20 characters
fun String.isTooLong(): Boolean = this.length > 20
