// Task 5.4.1: main program that tests the isTooLong() extension function

fun main() {
    // A short string (5 characters)
    val shortString = "Hello"
    val exactString = "12345678901234567890"
    val longString = "This string is definitely too long!"

    // Test the extension function on each string and print the results
    println("\"$shortString\" isTooLong: ${shortString.isTooLong()}")   // false
    println("\"$exactString\" isTooLong: ${exactString.isTooLong()}")   // false
    println("\"$longString\" isTooLong: ${longString.isTooLong()}")     // true
}
