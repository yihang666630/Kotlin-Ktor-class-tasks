// Task 8.3: functions for analysing weather station temperature data

// Import the Path class and the forEachLine extension
import kotlin.io.path.Path
import kotlin.io.path.forEachLine

// A record pairs a weather station name (String) with a temperature (Double)
typealias Record = Pair<String, Double>

// Read station and temperature data from the named CSV file.
// Each line of the file has the form "station name,temperature".
fun fetchData(filename: String) = buildList {
    Path(filename).forEachLine { line ->
        // Split the line on the comma separator into [name, temperature]
        val parts = line.split(",")
        // Only process lines that contain both a name and a temperature
        if (parts.size == 2) {
            val name = parts[0].trim()
            // Parse the temperature as a Double (after trimming whitespace)
            val temperature = parts[1].trim().toDouble()
            add(Pair(name, temperature))
        }
    }
}

// Compute the average temperature across the whole dataset
// (The task also asks to compute this inside main() with a single line of code,
//  using data.map { it.second }.average(), instead of calling this function.)
fun averageTemp(data: List<Record>): Double {
    var sum = 0.0

    for (record in data) {
        sum += record.second
    }
    // Return the total divided by the number of records
    return sum / data.size
}
