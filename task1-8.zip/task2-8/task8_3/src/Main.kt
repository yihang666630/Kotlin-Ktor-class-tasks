// Task 8.3: weather station temperature analysis program

import kotlin.system.exitProcess

fun main(args: Array<String>) {
    if (args.size != 1) {
        println("Error: no filename supplied on the command line")
        exitProcess(1)
    }

    // Read all (station, temperature) records from the named file
    val data = fetchData(args[0])

    // Find the record with the lowest temperature (minByOrNull is null-safe)
    val coldest = data.minByOrNull { it.second }
    // Find the record with the highest temperature (maxByOrNull is null-safe)
    val warmest = data.maxByOrNull { it.second }

    // Guard against an empty dataset before accessing the records
    if (coldest != null && warmest != null) {
        println("Coldest: ${coldest.first} at ${coldest.second}")
        println("Warmest: ${warmest.first} at ${warmest.second}")
    }

    // Compute the average temperature with a single line of code:
    // map each record to its temperature, then average() the resulting list
    val average = data.map { it.second }.average()

    println("Average temperature: %.2f".format(average))
}
