// Task 7.7.2: a simple menu-driven phone book simulator

// Import the Path class and the exists() extension
import kotlin.io.path.Path
import kotlin.io.path.exists

const val CSV_FILENAME = "phone.csv"

fun main() {
    // Create an empty database
    val database = createDatabase()

    // If the CSV file already exists, load its contents into the database
    if (Path(CSV_FILENAME).exists()) {
        database.load(CSV_FILENAME)
        println("Loaded ${database.size} entries from $CSV_FILENAME")
    }

    // Run the interactive menu until the user chooses to save and exit
    while (true) {
        println()
        println("=== Phone Book Simulator ===")
        println("1. Search")
        println("2. Add")
        println("3. List all")
        println("4. Save and Exit")
        print("Choose> ")

        // Read the user's choice and remove any surrounding whitespace
        val choice = readln().trim()

        // Handle the choice with a when expression
        when (choice) {
            // Option 1: search for a name
            "1" -> {
                print("Name> ")

                val name = readln().trim()
                val number = database[name]
                if (number != null) {
                    println("$name: $number")
                }
                else {
                    println("'$name' not found")
                }
            }
            // Option 2: add or update a name/number pairing
            "2" -> {
                print("Name> ")
                val name = readln().trim()
                print("Number> ")
                val number = readln().trim()
                // Insert (or replace) the pairing in the database
                database[name] = number
                println("Added/updated: $name -> $number")
            }
            // Option 3: list all entries
            "3" -> {
                // Check whether the database is empty
                if (database.isEmpty()) {
                    println("No entries in the phone book.")
                }
                else {
                    // Print every name/number pairing in the database
                    println("\n--- Phone Book ---")
                    database.forEach { (name, number) ->
                        println("$name: $number")
                    }
                    println("--- End ---")
                }
            }
            // Option 4: save the database and exit the program
            "4" -> {
                // Write the database contents back to the CSV file
                database.save(CSV_FILENAME)
                println("Saved ${database.size} entries to $CSV_FILENAME. Goodbye!")
                break // Exit the menu loop
            }
            // Any other input is rejected
            else -> println("Invalid choice. Please try again.")
        }
    }
}
