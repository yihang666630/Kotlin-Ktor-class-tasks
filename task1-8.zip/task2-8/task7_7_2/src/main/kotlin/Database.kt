// Task 7.7.2: functions for loading and saving the phone database

// Import the Path class and its file I/O extensions
import kotlin.io.path.Path
import kotlin.io.path.forEachLine
import kotlin.io.path.writeText

// A database is simply a map from a person's name to their phone number
typealias Database = MutableMap<String, String>

// Create a new, empty database
fun createDatabase() = mutableMapOf<String, String>()

// Extension function: load the contents of the CSV file into this database
fun Database.load(filename: String) {
    // Read the file line by line; each line holds one "name,number" pairing
    Path(filename).forEachLine { line ->
        val parts = line.split(",")
        // Only process lines that contain at least a name and a number
        if (parts.size >= 2) {
            val name = parts[0].trim()
            // The number is everything after the first comma (this also handles
            // numbers that themselves contain commas), trimmed of whitespace
            val number = parts.drop(1).joinToString(",").trim()
            // Insert the name/number pairing into the map
            this[name] = number
        }
    }
}

// Extension function: write the contents of this database to a CSV file
fun Database.save(filename: String) {
    // Build one "name,number" string per entry, joined by newlines
    val content = this.map { "${it.key},${it.value}" }.joinToString("\n")
    Path(filename).writeText(content) //overwritting any previous version
}
