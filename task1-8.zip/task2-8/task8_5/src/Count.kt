// Task 8.5: an example of a higher-order function

// Extension function: count the characters of the receiver string for which
// the supplied predicate (a function from Char to Boolean) returns true
fun String.howMany(include: (Char) -> Boolean): Int {
    var count = 0
    // Iterate over every character of the receiver string
    for (ch in this) {
        // If the predicate accepts this character, increment the count
        if (include(ch)) {
            count++
        }
    }

    return count
}
