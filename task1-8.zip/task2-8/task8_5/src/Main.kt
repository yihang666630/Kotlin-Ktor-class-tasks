// Task 8.5: testing the higher-order function howMany()

fun main() {
    // The string on which all the tests are performed
    val text = "Hello, World!"

    // Count the vowels using a lambda; lowercase() makes the check case-insensitive
    val vowels = text.howMany { it.lowercase() in "aeiou" }
    println("Vowels: $vowels")

    // Count the uppercase letters
    val uppercase = text.howMany { it.isUpperCase() }
    println("Uppercase: $uppercase")

    // Count the letters (excluding punctuation, spaces, etc.)
    val letters = text.howMany { it.isLetter() }
    println("Letters: $letters")

    // Count the whitespace characters
    val spaces = text.howMany { it.isWhitespace() }
    println("Spaces: $spaces")

    // Compare the results with the standard library's count() function;
    // both approaches should produce identical values.
    println("\n--- Comparison with count() ---")

    // Count the vowels using count()
    val vowelsCount = text.count { it.lowercase() in "aeiou" }
    println("Vowels (count): $vowelsCount")

    // Count the uppercase letters using count()
    val uppercaseCount = text.count { it.isUpperCase() }
    println("Uppercase (count): $uppercaseCount")

    // Count the letters using count()
    val lettersCount = text.count { it.isLetter() }
    println("Letters (count): $lettersCount")

    // Count the whitespace characters using count()
    val spacesCount = text.count { it.isWhitespace() }
    println("Spaces (count): $spacesCount")
}
