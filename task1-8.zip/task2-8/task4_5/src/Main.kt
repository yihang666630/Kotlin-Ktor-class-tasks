// Task 4.5: summing the odd integers between 1 and a given limit


import kotlin.system.exitProcess

fun main(args: Array<String>) {
    if (args.size != 1) {
        println("Error: you need to offer a limit number")
        exitProcess(1)
    }

    val lim = args[0].toInt()
    var sum = 0

    // Iterate over every integer from 1 up to and including the limit
    for (n in 1..lim) {
        // If the current number is odd, add it to the running total
        if (n % 2 != 0) {
            sum += n
        }
    }

    println("Final result: $sum")
}
