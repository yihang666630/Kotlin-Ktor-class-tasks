// Task 4.2: simulating a pizza order using an if expression and a Char range

fun main() {
    // Print the heading of the menu
    println("PIZZA MENU")
    // Print a blank line after the heading
    println()

    // A map holding the four pizza options and their labels (a, b, c and d)
    val menu = mapOf(
        "(a)" to "Margherita",
        "(b)" to "Quattro Stagioni",
        "(c)" to "Seafood",
        "(d)" to "Hawaiian"
    )


    for ((key, value) in menu) {
        println("$key: $value")
    }


    println()
    print("Choose your pizza (a-d): ")
    val userIn = readln().lowercase()

    // Use an if expression: valid input is a single character in the range 'a'..'d'
    if (userIn.length == 1 && userIn[0] in 'a'..'d') {
        println("Order accepted")
    }

    else {
        println("Invalid choice!")
    }
}
