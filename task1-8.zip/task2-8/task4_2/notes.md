1. Ranges are not limited to integers. You can also define floating point ranges, ranges of characters, even ranges of strings:
   0.0..100.0
   'a'..'z'
   "aaa".."zzz"
2. 