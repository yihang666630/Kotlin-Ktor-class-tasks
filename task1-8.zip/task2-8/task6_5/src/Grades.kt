// Task 6.5: the exam grading function that will be tested

// Convert a mark (0-100) into a grade using a when expression
fun grade(mark: Int) = when (mark) {
    in 0..39 -> "Fail"
    in 40..69 -> "Pass"
    in 70..100 -> "Distinction"
    else -> "?"
}
