// Task 6.5: demo program for the grade() function

fun main() {
    // Call grade() with a selection of marks and print the results
    println("25 -> ${grade(25)}")   // 25 is a Fail
    println("47 -> ${grade(47)}")   // 47 is a Pass
    println("62 -> ${grade(62)}")   // 62 is a Pass
    println("78 -> ${grade(78)}")   // 78 is a Distinction
}
