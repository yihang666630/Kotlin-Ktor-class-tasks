// Task 6.5: unit tests for grade() written with the Kotest framework

import io.kotest.assertions.assertSoftly
// Import Kotest's withClue helper (adds a message to each assertion)
import io.kotest.assertions.withClue
// Import the FreeSpec testing style
import io.kotest.core.spec.style.FreeSpec
// Import the shouldBe matcher (asserts that a value equals an expected value)
import io.kotest.matchers.shouldBe

// Suppress the "unused" warning for the test class name
@Suppress("unused")
class GradeTest : FreeSpec({
    "Marks between 0 and 39 give Fail" {
        // assertSoftly makes sure all three assertions are evaluated
        assertSoftly {
            withClue("Mark=0") { grade(0) shouldBe "Fail" }
            withClue("Mark=25") { grade(25) shouldBe "Fail" }
            withClue("Mark=39") { grade(39) shouldBe "Fail" }
        }
    }

    // Marks below 0 are not valid grades
    "Marks below 0 give ?" {
        assertSoftly {
            withClue("Mark=-1") { grade(-1) shouldBe "?" }
            withClue("Mark=-5") { grade(-5) shouldBe "?" }
        }
    }

    // Marks between 40 and 69 give a Pass
    "Marks between 40 and 69 give Pass" {
        assertSoftly {
            withClue("Mark=40") { grade(40) shouldBe "Pass" }
            withClue("Mark=55") { grade(55) shouldBe "Pass" }
            withClue("Mark=69") { grade(69) shouldBe "Pass" }
        }
    }

    // Marks between 70 and 100 give a Distinction
    "Marks between 70 and 100 give Distinction" {
        assertSoftly {
            withClue("Mark=70") { grade(70) shouldBe "Distinction" }
            withClue("Mark=85") { grade(85) shouldBe "Distinction" }
            withClue("Mark=100") { grade(100) shouldBe "Distinction" }
        }
    }

    // Marks above 100 are not valid grades
    "Marks above 100 give ?" {
        assertSoftly {
            withClue("Mark=101") { grade(101) shouldBe "?" }
            withClue("Mark=105") { grade(105) shouldBe "?" }
        }
    }
})
