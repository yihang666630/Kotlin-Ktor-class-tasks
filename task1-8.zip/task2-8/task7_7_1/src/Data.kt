// Task 7.7.1: reading a dataset of numbers from a file

import kotlin.io.path.Path
import kotlin.io.path.forEachLine

// buildList() provides a hidden MutableList as the receiver of the lambda,
fun readData(filename: String) = buildList {
    Path(filename).forEachLine {
        // Parse the current line as a Float and append it to the list
        add(it.toFloat())
    }
}
