// Task 7.7.1: statistics functions for a list of numbers

// Compute the median of a list of Float values
fun median(values: List<Float>): Float {

    val sorted = values.sorted()
    val size = sorted.size

    return when {
        // Odd-sized list: the median is the middle value
        size % 2 == 1 -> sorted[size / 2]
        // Even-sized list: the median is the average of the two middle values
        else -> (sorted[size / 2 - 1] + sorted[size / 2]) / 2f
    }
}

// Print the key statistics for the given list of values
fun displayStatistics(values: List<Float>) {
    println("Minimum: ${values.minOrNull()}")
    println("Maximum: ${values.maxOrNull()}")
    println("Mean: ${values.average()}")
    println("Median: ${median(values)}")
}
