// Task 7.7.1: program that displays statistics for a numeric dataset

fun main(args: Array<String>) {
    // Check that a file name was supplied on the command line
    if (args.size != 1) {
        // Print a usage message if it was not
        println("Usage: <filename>")
        return
    }

    // Read the numbers from the named file into a list of Float values
    val data = readData(args[0])

    // Compute and display the statistics (min, max, mean, median)
    displayStatistics(data)
}
