// Task 8.4.2: benchmarking program showing the performance impact of sequences

// Import the File class for reading the text file
import java.io.File
// Import exitProcess for terminating with an error status
import kotlin.system.exitProcess
// Import measureTime to time the execution of code blocks
import kotlin.time.measureTime

fun main(args: Array<String>) {
    if (args.size != 1) {
        println("Error: no filename on command line")
        exitProcess(1)
    }

    // Version 1: WITHOUT sequences.
    // readLines() loads every line into a list, and each filter()/map() step
    // creates yet another intermediate list in memory.
    val timeWithout = measureTime {
        File(args[0]).readLines()                    // read all lines into a List
            .filter { it.isNotBlank() }              // drop the blank lines
            .filter { it.length < 10 }               // drop lines with 10+ characters
            .map { it.lowercase() }                  // convert remaining lines to lowercase
    }

    // Version 2: WITH sequences.
    // useLines() provides a Sequence of lines and filter()/map() are lazy,
    // so no intermediate lists are created; toList() collects the final result.
    val timeWith = measureTime {
        File(args[0]).useLines { seq ->              // open a lazy Sequence of lines
            seq.filter { it.isNotBlank() }           // drop the blank lines
                .filter { it.length < 10 }           // drop lines with 10+ characters
                .map { it.lowercase() }              // convert remaining lines to lowercase
                .toList()                            // collect the final results
        }
    }

    println("Without sequence: $timeWithout")
    println("With sequence: $timeWith")
}
