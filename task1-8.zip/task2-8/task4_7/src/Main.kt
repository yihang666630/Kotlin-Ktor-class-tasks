// Task 4.7: finding the longest line in a text file

import kotlin.io.path.useLines
// Import the java.io.File class for constructing a Path object
import java.io.File
// Import exitProcess for terminating with an error status
import kotlin.system.exitProcess

fun main(args: Array<String>) {
    if (args.size != 1) {
        println("Error: you need to offer a file path")
        exitProcess(1)
    }

    val filePath = File(args[0]).toPath()

    var maxLineNum = 0
    var maxLen = 0
    var curLineNum = 0

    filePath.useLines {
        for (line in it) {   //lambda expression
            curLineNum++
            if (line.length > maxLen) {
                maxLen = line.length
                maxLineNum = curLineNum
            }
        }
    }

    // Report the longest line in the required format
    println("Line $maxLineNum is the longest (length = $maxLen)")
}
