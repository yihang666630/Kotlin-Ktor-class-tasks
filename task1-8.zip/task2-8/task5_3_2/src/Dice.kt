// Task 5.3.2: the rollDice() function for rolling several dice at once

import kotlin.random.Random

fun rollDice(sides: Int = 6, dice: Int = 1) {
    if (sides !in setOf(4, 6, 8, 10, 12, 20)) {
        println("Error: cannot have a $sides-sided die")
        return
    }

    // Announce the batch of dice being rolled
    println("Rolling $dice d$sides...")

    // Accumulator holding the total score across all dice
    var total = 0

    // Roll each die in turn
    for (i in 1..dice) {
        val result = Random.nextInt(1, sides + 1)
        println("Die $i: $result")
        // Add this die's value to the running total
        total += result
    }

    // Display the total score across all dice
    println("Your final result is: $total")
}
