// Task 5.3.2: main program that rolls dice according to a dice specification

import kotlin.system.exitProcess

fun main(args: Array<String>) {
    if (args.size != 1) {
        println("Error: please offer a dice specification in 'xdy' format, e.g. 3d6")
        exitProcess(1)
    }

    // Parse the specification by splitting on the letter 'd' (e.g. "3d8" -> ["3", "8"])
    val diceSpec = args[0].lowercase().split("d")

    if (diceSpec.size != 2) {
        println("Error: Invalid dice format '${args[0]}'. Expected format like '3d8'")
        exitProcess(1)
    }

    // Convert both parts to integers (null if a part is not numeric)
    val dice = diceSpec[0].toIntOrNull()
    val sides = diceSpec[1].toIntOrNull()

    // Refuse to continue if either part is not a number
    if (dice == null || sides == null) {
        println("Error: Invalid dice format '${args[0]}'. Expected format like '3d8'")
        exitProcess(1)
    }

    rollDice(dice = dice, sides = sides) // nmaed arguments
}
