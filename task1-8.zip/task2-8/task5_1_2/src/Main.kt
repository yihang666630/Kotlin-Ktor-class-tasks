// Task 5.1.2: main program that rolls a die with a given number of sides

import kotlin.system.exitProcess

fun main(args: Array<String>) {
    if (args.size != 1) {
        println("Error: you need to offer the number of sides of a dice")
        exitProcess(1)
    }

    // Convert the argument (a string) into the number of die sides
    val sideNum = args[0].toInt()
    rollDie(sideNum)
}
